import React from 'react';

const App = () => (
  <div>
    <h1>Bench Bnb</h1>
  </div>
);

export default App;
