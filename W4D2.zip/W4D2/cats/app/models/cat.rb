class Cat < ApplicationRecord
  CAT_COLORS = %w(black yellow orange)
  CAT_SEX = %w(M F)

  validates :color, inclusion:{ in: CAT_COLORS }
  validates :sex, length: { is: 1 }
  validates :sex, inclusion: { in: CAT_SEX }
  validates :color, :birth_date, :name, :sex, :description, presence: true

  has_many :cat_rental_requests,
  foreign_key: :cat_id,
  class_name: 'CatRentalRequest',
  dependent: :destroy


end
