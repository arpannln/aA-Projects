module.exports = {entry: "./app.js", output: "./bundle.js", devtool: "source-map"};
