/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 1);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

// const MovingObject = require('./lib/moving_object.js');
// window.MovingObject = MovingObject;
//
// const Util = require('./lib/util.js');
// window.Util = Util;

// const Asteroid = require('./lib/asteroid.js');
// window.Asteroid = Asteroid;

// const Game = require('./lib/game.js');
// window.Game = Game;

const GameView = __webpack_require__(6);
window.GameView = GameView;


/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(0);
module.exports = __webpack_require__(0);


/***/ }),
/* 2 */
/***/ (function(module, exports) {

const MovingObject = function(options) {
  this.pos = options['pos'];
  this.vel = options['vel'];
  this.radius = options['radius'];
  this.color = options['color'];
};

MovingObject.prototype.draw = function(ctx) {
  console.log(this);
  ctx.beginPath();
  console.log(`x ${this.pos[0]}`);
  console.log(`y ${this.pos[1]}`);
  ctx.arc(this.pos[0], this.pos[1], this.radius, 0, 2 * Math.PI);
  // ctx.arc(100, 100, this.radius, 0, 2 * Math.PI);
  ctx.strokeStyle = "#000000";
  ctx.lineWidth = 5;
  ctx.stroke();
  ctx.fillStyle = this.color;
  ctx.fill();
};

MovingObject.prototype.move = function(ctx) {
  this.pos[0] += this.vel[0];
  this.pos[1] += this.vel[1];
  let x = this.pos[0];
  let y = this.pos[1];
  if (x < 0) this.pos[0] = 1000;
  if (x > 1000) this.pos[0] = 0;
  if (y < 0) this.pos[1] = 600;
  if (y > 600) this.pos[1] = 0;
};



// TEST CODE!!!

// const canvas = document.getElementById("canvas");
// let ctx = canvas.getContext("2d");
// let options = {
//   pos: [100,100],
//   vel: [0,0],
//   radius: 50,
//   color: '#00FF00'
// };
// let mo = new MovingObject(options);
// mo.draw(ctx);
//
// mo.vel = [20, 0];
// mo.move();
// mo.draw(ctx);


module.exports = MovingObject;


/***/ }),
/* 3 */
/***/ (function(module, exports) {

const Util = {
  inherits: function(childClass, parentClass) {
    childClass.prototype = Object.create(parentClass.prototype);
    childClass.prototype.constructor = childClass;
  },
  randomVec: function(length) {
    const deg = 2 * Math.PI * Math.random();
    return Util.scale([Math.sin(deg), Math.cos(deg)], length);
  },
  // Scale the length of a vector by the given amount.
  scale: function(vec, m) {
    return [vec[0] * m, vec[1] * m];
  }
};

module.exports = Util;


/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

const MovingObject = __webpack_require__(2);
const Util = __webpack_require__(3);

const Asteroid = function(options) {
  MovingObject.call(this, options);
  // this.color = options['color'] || "blue";
  this.color = "gray";
  this.radius = 25;

  this.vel = Util.randomVec(15);
};

Util.inherits(Asteroid, MovingObject);

// TEST CODE!!!

// const canvas = document.getElementById("canvas");
// let ctx = canvas.getContext("2d");
//
// let ast = new Asteroid({ pos: [100,100] });
// ast.draw(ctx);
// ast.move(ctx);
// ast.draw(ctx);


module.exports = Asteroid;


/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

const Asteroid = __webpack_require__(4);



const Game = function () {
  // console.log("game");
  this.asteroids = [];
  this.DIM_X = 1000;
  this.DIM_Y = 600;
  this.NUM_ASTEROIDS = 10;
  this.CANVAS = document.getElementById("canvas");
  this.CTX = this.CANVAS.getContext("2d");
  this.addAsteroids();
  // this.draw(this.CTX);
};


Game.prototype.randomPos = function () {
  return { pos: [Math.floor(Math.random() * this.DIM_X),
                 Math.floor(Math.random() * this.DIM_Y)] };
};

Game.prototype.addAsteroids = function () {
  // console.log("xxxxx");
  // console.log(this.NUM_ASTEROIDS);
  for (var i = 0; i < this.NUM_ASTEROIDS; i++) {
    let ast = new Asteroid(this.randomPos());
    // console.log("trying to draw an asteroid");
    this.asteroids.push(ast);
    // ast.draw(this.CTX);
  }
};

Game.prototype.draw = function () {
  this.CTX.clearRect(0,0,20000,20000);
  for (var i = 0; i < this.asteroids.length; i++) {
    this.asteroids[i].draw(this.CTX);
  }
};

Game.prototype.moveObjects = function () {
  for (var i = 0; i < this.asteroids.length; i++) {
    this.asteroids[i].move(this.CTX);
  }
};

let g = new Game();
// console.log(g.);

// while (true) {
//   g.moveObjects();
//   g.draw();
// }
//
// Game.prototype.moveAndDraw = function () {
//   // console.log(this);
//   this.moveObjects();
//   this.draw();
// };
//
// setInterval(g.moveAndDraw.bind(g), 100);

module.exports = Game;


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

const Game = __webpack_require__(5);

const GameView = function () {
  this.game = new Game();
  this.ctx = this.game.CTX;
};

const moveAndDraw = function (g) {
  g.moveObjects();
  g.draw();
};


GameView.prototype.start = function () {
  // console.log(this);
  let bound = moveAndDraw.bind(this, this.game);
  setInterval(bound, 50);
};

let gv = new GameView();
gv.start();
//
//
// Game.prototype.moveAndDraw = function () {
//   // console.log(this);
//   this.moveObjects();
//   this.draw();
// };
//
// setInterval(gv.game.moveAndDraw.bind(gv.game), 100);
//
//
module.exports = GameView;


/***/ })
/******/ ]);
//# sourceMappingURL=bundle.js.map