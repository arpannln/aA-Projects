// const MovingObject = require('./lib/moving_object.js');
// window.MovingObject = MovingObject;
//
// const Util = require('./lib/util.js');
// window.Util = Util;

// const Asteroid = require('./lib/asteroid.js');
// window.Asteroid = Asteroid;

// const Game = require('./lib/game.js');
// window.Game = Game;

const GameView = require('./lib/game_view.js');
window.GameView = GameView;
