import React from "react";
import TodoListItem from "./todo_list_item.jsx";
import {TodoForm} from "./todo_form.jsx";

export class TodoList extends React.Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    this.props.fetchTodos();
  }

  render() {
    const { todos, receiveTodo, createTodo } = this.props;

    const listOfTodos = todos.map(todo => (
      <TodoListItem
        store={todo}
        todo={ todo }
        key={todo.id}
        receiveTodo={ receiveTodo } />
    ));

    const form = <TodoForm
        createTodo={ createTodo }
       />;
    return (
      <div>
        {listOfTodos}
        {form}
      </div>
    );
  }

}


export default TodoList;
