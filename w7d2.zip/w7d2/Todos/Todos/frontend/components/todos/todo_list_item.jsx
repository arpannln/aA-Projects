import React from "react";


class TodoListItem extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const {todo} = this.props;

    return (
      <div>
        <h1>{todo.title}</h1>
        <h2>{todo.id}</h2>
        <p>{todo.body}</p>
        <p>{`${todo.done}`}</p>
      </div>
    );
  }
}


export default TodoListItem;
