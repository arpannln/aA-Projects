import React from 'react';

export class TodoForm extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      body: "",
      title: "",
      done: false
    };

    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit(e) {
    e.preventDefault();
    const todo = Object.assign({}, this.state, {id: new Date().getTime()});
    // const todoSend = {"todo": todo};
    this.props.createTodo({ todo }).then(() => this.setState({
      title: "",
      body: "",
      done: false
    }));
  }

  update(property) {
    return e => this.setState({[property]: e.target.value});
  }

  render() {
    return (
      <div>
        <form onSubmit={this.handleSubmit}>
          <input
            type="text"
            name="todo[title]"
            value={this.state.title}
            onChange={this.update('title')}></input>
          <input
            type = "text"
            name = "todo[body]"
            value={this.state.body}
            onChange={this.update('body')}></input>
          <input type = "checkbox" name = "todo[done]"></input>
          <button>Create Todo</button>
        </form>

      </div>
    );
  }
}
