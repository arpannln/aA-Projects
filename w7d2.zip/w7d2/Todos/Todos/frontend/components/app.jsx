import React from 'react';
import ReactDOM from 'react-dom';

// import TodoListContainer from "./todos/todo_list.jsx";
import TodoListContainer from "./todos/todo_list_container.jsx";


const App = () => (
  <div>
    <h1>Todo List</h1>
    <TodoListContainer />
  </div>
);

export default App;
