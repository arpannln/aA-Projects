export const makeTodo = (todo) => {
  return $.ajax({
    url: "/api/todos",
    method: "POST",
    dataType: "json",
    data: todo
  });
};

export const getTodos = () => {
  return $.ajax({
    url: "/api/todos",
    method: "GET",
    dataType: "json",
  });
};
