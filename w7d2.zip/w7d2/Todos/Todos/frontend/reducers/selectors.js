const allTodos = (state) => {
  console.log(state);
  let keys = Object.keys(state.todos);

  let todos = keys.map((el) =>
      state.todos[el]
  );

  return todos;
};

export default allTodos;
