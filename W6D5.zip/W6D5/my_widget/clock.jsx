import React from 'react';

class Clock extends React.Component {

  constructor() {
    super();
    this.state = {date: new Date()};
    this.getDate = this.getDate.bind(this);
    this.tick = this.tick.bind(this);
  }

  componentDidMount() {
    setInterval(this.tick, 1000);
  }

  tick() {
    this.setState({date: new Date()});
  }

  getDate() {
    return this.state.date.slice(0, 15);
  }

  render() {
    this.hours = this.state.date.getHours();
    this.minutes = this.state.date.getMinutes();
    this.seconds = this.state.date.getSeconds();
    if (this.seconds < 10) {
      this.seconds = '0' + this.seconds;
    }
    if (this.minutes < 10) {
      this.minutes = '0' + this.minutes;
    }
    let date = this.state.date.toString().slice(0, 15);
    return (
    <div>
      <h1>Clock</h1>
        <section className = "first-box">
          <p>
            <span>Time:</span>
            <span>{this.hours}:{this.minutes}:{this.seconds}PDT</span>
          </p>
          <p>
          <span>Date:</span>
            <span>{date}</span>
          </p>
        </section>
    </div>
    );
  }
}

    // <h1>{this.getDate()}</h1>
export default Clock;
