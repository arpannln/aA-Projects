import React from 'react';
import Clock from './clock';

class Root extends React.Component {
  constructor() {
    super();
    console.log('hi');
  }

  render() {
    return (
      <div>
        <Clock />
      </div>
    );
  }
}
export default Root;
