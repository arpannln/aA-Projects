class Clock {
  constructor() {
    // 1. Create a Date object.
    let date = new Date();
    this.hours = date.getHours();
    this.minutes = date.getMinutes();
    this.seconds = date.getSeconds();
    // 2. Store the hours, minutes, and seconds.
    // 3. Call printTime.
    this.printTime();
    setInterval(this._tick.bind(this), 1000);
    // 4. Schedule the tick at 1 second intervals.
  }

  printTime() {
    // Format the time in HH:MM:SS
    // Use console.log to print it.

    console.log(`${this.hours} : ${this.minutes} : ${this.seconds}`);
  }

  _tick() {
    this.seconds++;
    if (this.seconds === 60) {
      this.seconds = 0;
      this.minutes++;
    }
    if (this.minutes === 60) {
      this.minutes = 0;
      this.hours++;
    }
    if (this.hours === 25 ) {
      this.hours = 1;
    }
    this.printTime();
  }
}

const clock = new Clock();

// clock.printTime();
