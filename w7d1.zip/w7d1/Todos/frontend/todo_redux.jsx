import React from 'react';
import ReactDOM from 'react-dom';
import configureStore from './store/store.js';
import {receiveTodo, receiveTodos} from './actions/todo_actions';
import allTodos from "./reducers/selectors.js";
import Root from "./components/root.jsx";




document.addEventListener("DOMContentLoaded", () => {
  const root = document.getElementById("root");
  let store = configureStore();
  ReactDOM.render(<Root store = {store} />, root);


  console.log(store);
  window.store = store;
  window.receiveTodo = receiveTodo;
  window.receiveTodos = receiveTodos;
  window.allTodos = allTodos;

  const newTodos = [{
    id: 1,
    title: 'wash car',
    body: 'without soap',
    done: false
  },
   {
      id: 2,
      title: 'wash dog',
      body: 'with shampoo',
      done: true
    },
  ];

  const psych = {
    1: {
      id: 1,
      title: 'wash car',
      body: 'with soap',
      done: false
    },
    2: {
      id: 2,
      title: 'wash dog',
      body: 'with shampoo',
      done: true
    },
  };

  store.getState(); // should return default state object
  store.dispatch(receiveTodo({ id: 3, title: 'New Todo' }));
  store.getState(); // should include the newly added todo
  // store.dispatch(receiveTodos(newTodos));
  store.getState(); // should return only the new todos

  console.log(window.allTodos(psych));
  });
