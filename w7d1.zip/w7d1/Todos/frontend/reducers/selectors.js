const allTodos = (state) => {
  let keys = Object.keys(state);
  let todos = keys.map((el) =>
      state[el]
  );

  return todos;
};

export default allTodos;
