import React from "react";
// import connect from "./todo_list_container.jsx";

const TodoList = ( props ) => (
  <div>
    <h3>Todo List goes here!</h3>
    <h3></h3>
  </div>
);

export default TodoList;
